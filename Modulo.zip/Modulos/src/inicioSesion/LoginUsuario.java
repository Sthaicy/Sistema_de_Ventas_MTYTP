/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package inicioSesion;
import java.util.*;
import com.toedter.calendar.JDateChooser;
import javax.swing.table.DefaultTableModel;
import dba.Mysql;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import java.sql.SQLException;
import java.util.List;
import java.security.SecureRandom;
import java.security.MessageDigest;
import java.security.GeneralSecurityException;
import java.security.spec.KeySpec;
import java.util.Base64;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
/**
 *
 * @author NEW
 */
public class LoginUsuario extends javax.swing.JFrame {
    DefaultTableModel model;
    Connection conn;
    Statement sent;
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(LoginUsuario.class.getName());
    private boolean passwordVisible = false;
    /**
     * Creates new form Login
     */
    public LoginUsuario() {
        initComponents();
        conn=Mysql.getConnection();
        jPasswordField1.setText("");
       
        
    }

    private void iniciarSesion() {

        String identificador = jTextField1.getText().trim();
        char[] password = jPasswordField1.getPassword();

        if (identificador.isEmpty() || password.length == 0) {
            JOptionPane.showMessageDialog(this,
                    "Ingresa tu usuario o correo y contraseña.");
            java.util.Arrays.fill(password, '\0');
            return;
        }

        String sql = "SELECT id_usuario, nombre, password_hash "
                + "FROM usuarios "
                + "WHERE (nombre_usuario = ? OR correo = ?) "
                + "AND activo = 1";

        try {

            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setString(1, identificador);
            ps.setString(2, identificador);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                int idUsuario = rs.getInt("id_usuario");
                String nombre = rs.getString("nombre");
                String hashGuardado = rs.getString("password_hash");

                boolean passwordCorrecta =
                        verificarPassword(password, hashGuardado);

                java.util.Arrays.fill(password, '\0');
                jPasswordField1.setText("");
                if (passwordCorrecta) {

                    List<String> roles = obtenerRoles(idUsuario);

                    if (roles.isEmpty()) {
                        JOptionPane.showMessageDialog(this,
                                "Este usuario no tiene roles asignados.");
                        rs.close();
                        ps.close();
                        return;
                    }
                   actualizarUltimoAcceso(idUsuario);

                    JOptionPane.showMessageDialog(this,
                            "Bienvenido, " + nombre
                            + "\nRol: " + roles.get(0));

                    abrirMenuPorRol(roles, idUsuario);

                    rs.close();
                    ps.close();
                    return;

                } else {
                    JOptionPane.showMessageDialog(this,
                            "Usuario o contraseña incorrectos.");
                }
            } else {

                java.util.Arrays.fill(password, '\0');
                jPasswordField1.setText("");

                JOptionPane.showMessageDialog(this,
                        "Usuario o contraseña incorrectos.");
            }

            rs.close();
            ps.close();

        } catch (SQLException | GeneralSecurityException e) {

            java.util.Arrays.fill(password, '\0');
            jPasswordField1.setText("");

            JOptionPane.showMessageDialog(this,
                    "Error al iniciar sesión: " + e.getMessage());
        }
    }
    private void abrirMenuPorRol(List<String> roles, int idUsuario) {
        if (roles == null || roles.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "El usuario no tiene ningún rol asignado.",
                    "Acceso denegado",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        String rol = roles.get(0).toUpperCase();

        switch (rol) {
            case "ADMINISTRADOR":
                new MenuAdmin(idUsuario).setVisible(true);
                break;

            case "ANFITRION":
                new MenuAnfitrion(idUsuario).setVisible(true);
                break;

            case "ALMACEN":
                new MenuAlmacen(idUsuario).setVisible(true);
                break;

            case "CLIENTE":
                new MenuCliente(idUsuario).setVisible(true);
                break;

            case "COMERCIAL":
                new MenuComercial(idUsuario).setVisible(true);
                break;

            case "TIENDA":
                new MenuTienda(idUsuario).setVisible(true);
                break;

            default:
                JOptionPane.showMessageDialog(this,
                        "No existe un menú para el rol: " + rol,
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
                return;
        }

        this.dispose();
    }
    private boolean verificarPassword(char[] password, String hash)
        throws GeneralSecurityException {
        if (hash == null) {
            return false;
        }

        String[] partes = hash.split("\\$", -1);

        if (partes.length != 4 || !partes[0].equals("PBKDF2")) {
            return false;
        }

        try {

            int iteraciones = Integer.parseInt(partes[1]);

            if (iteraciones < 100000 || iteraciones > 1000000) {
                return false;
            }

            byte[] salt = Base64.getDecoder().decode(partes[2]);
            byte[] hashOriginal = Base64.getDecoder().decode(partes[3]);

            if (salt.length != 16 || hashOriginal.length != 32) {
                return false;
            }

            PBEKeySpec spec = new PBEKeySpec(
                    password, salt, iteraciones, 256
            );

            SecretKeyFactory factory =
                    SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");

            byte[] hashCalculado = factory.generateSecret(spec).getEncoded();

            spec.clearPassword();

            return MessageDigest.isEqual(hashOriginal, hashCalculado);

        } catch (IllegalArgumentException e) {
            return false;
        }
    }
    
    private List<String> obtenerRoles(int idUsuario) throws SQLException {

        List<String> roles = new ArrayList<>();

        String sql = "SELECT r.nombre "
                + "FROM roles r "
                + "INNER JOIN usuario_roles ur ON r.id_rol = ur.id_rol "
                + "WHERE ur.id_usuario = ?";

        try {

            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, idUsuario);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                roles.add(rs.getString("nombre"));
            }

            rs.close();
            ps.close();

        } catch (SQLException e) {
            throw e;
        }

        return roles;
    }
    
    private void actualizarUltimoAcceso(int idUsuario) throws SQLException {

        String sql = "UPDATE usuarios "
                + "SET ultimo_acceso = CURRENT_TIMESTAMP "
                + "WHERE id_usuario = ?";

        try {

            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, idUsuario);

            ps.executeUpdate();
            ps.close();

        } catch (SQLException e) {
            throw e;
        }
    }
    
    private String generarHash(char[] password)
        throws GeneralSecurityException {

        int iteraciones = 600000;

        byte[] salt = new byte[16];
        new SecureRandom().nextBytes(salt);

        PBEKeySpec spec = new PBEKeySpec(
                password, salt, iteraciones, 256
        );

        SecretKeyFactory factory =
                SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");

        byte[] hash = factory.generateSecret(spec).getEncoded();

        spec.clearPassword();

        return "PBKDF2$" + iteraciones + "$"
                + Base64.getEncoder().encodeToString(salt) + "$"
                + Base64.getEncoder().encodeToString(hash);
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton1 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jTextField1 = new javax.swing.JTextField();
        jPanel2 = new javax.swing.JPanel();
        jPasswordField1 = new javax.swing.JPasswordField();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jButton1.setText("INICIAR SESIÓN");
        jButton1.addActionListener(this::jButton1ActionPerformed);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel1.setText("INICIO DE SESIÓN");

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Nombre de Usuario o Correo:", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 1, 12))); // NOI18N

        jTextField1.addActionListener(this::jTextField1ActionPerformed);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTextField1)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTextField1)
        );

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Contraseña:", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 1, 12))); // NOI18N

        jPasswordField1.setText("jPasswordField1");
        jPasswordField1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 1, 12))); // NOI18N

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPasswordField1, javax.swing.GroupLayout.PREFERRED_SIZE, 184, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPasswordField1, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jButton2.setText("MOSTRAR");
        jButton2.addActionListener(this::jButton2ActionPerformed);

        jButton3.setText("REGISTRARSE");
        jButton3.addActionListener(this::jButton3ActionPerformed);

        jButton4.setText("CERRAR");
        jButton4.addActionListener(this::jButton4ActionPerformed);

        jButton5.setText("INICAR SIN SESIÓN");
        jButton5.addActionListener(this::jButton5ActionPerformed);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(17, 17, 17)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(jButton4))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jButton5)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jButton2))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jButton3))
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                                .addGap(0, 0, Short.MAX_VALUE))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(37, 37, 37)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 169, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton2)
                    .addComponent(jButton5, javax.swing.GroupLayout.Alignment.TRAILING))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(jButton3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 24, Short.MAX_VALUE)
                .addComponent(jButton4)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField1ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
         iniciarSesion();
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
          if (passwordVisible) {
            jPasswordField1.setEchoChar('*');
            jButton2.setText("Mostrar");
            passwordVisible = false;
        } else {
            jPasswordField1.setEchoChar((char) 0);
            jButton2.setText("Ocultar");
            passwordVisible = true;
        }
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        registro formulario = new registro();
        formulario.setLocationRelativeTo(this);
        formulario.setVisible(true);
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        MenuCliente ventana = new MenuCliente(-1);
        ventana.setLocationRelativeTo(null);
        ventana.setVisible(true);
        this.dispose();
        
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        this.dispose();
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton4ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new LoginUsuario().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPasswordField jPasswordField1;
    private javax.swing.JTextField jTextField1;
    // End of variables declaration//GEN-END:variables
}
