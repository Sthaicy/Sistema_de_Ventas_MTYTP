package dao;

import conexion.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.sql.Date;

public class IntegracionDAO {

    public ArrayList<Object[]> listarPedidosTienda() {
        ArrayList<Object[]> lista = new ArrayList<>();
        String sql = "SELECT id_pedido, fecha, id_cliente, total, estado "
                   + "FROM pedidos ORDER BY fecha DESC";

        try (Connection conexion = Conexion.conectar();
             PreparedStatement sentencia = conexion.prepareStatement(sql);
             ResultSet resultado = sentencia.executeQuery()) {

            while (resultado.next()) {
                Object[] pedido = {
                    resultado.getInt("id_pedido"),
                    resultado.getTimestamp("fecha"),
                    resultado.getInt("id_cliente"),
                    resultado.getDouble("total"),
                    resultado.getString("estado")
                };
                lista.add(pedido);
            }
        } catch (Exception e) {
            System.out.println("Error al consultar pedidos: " + e.getMessage());
        }
        return lista;
    }
        // 2. RESUMEN DE PEDIDOS AGRUPADOS POR ESTADO
    public ArrayList<Object[]> resumenPedidosPorEstado() {
        ArrayList<Object[]> lista = new ArrayList<>();

        String sql = "SELECT estado, "
                   + "COUNT(*) AS cantidad_pedidos, "
                   + "COALESCE(SUM(total), 0) AS monto_total "
                   + "FROM pedidos "
                   + "GROUP BY estado "
                   + "ORDER BY cantidad_pedidos DESC";

        try (Connection conexion = Conexion.conectar();
             PreparedStatement sentencia = conexion.prepareStatement(sql);
             ResultSet resultado = sentencia.executeQuery()) {

            while (resultado.next()) {
                Object[] fila = {
                    resultado.getString("estado"),
                    resultado.getInt("cantidad_pedidos"),
                    resultado.getDouble("monto_total")
                };

                lista.add(fila);
            }

        } catch (Exception e) {
            System.out.println("Error al resumir pedidos: " + e.getMessage());
        }

        return lista;
    }

    // 3. PEDIDOS ENTREGADOS POR PERIODO
    public ArrayList<Object[]> pedidosEntregadosPorPeriodo(
            Date desde, Date hasta) {

        ArrayList<Object[]> lista = new ArrayList<>();

        String sql = "SELECT DATE(fecha) AS dia, "
                   + "COUNT(*) AS cantidad_pedidos, "
                   + "COALESCE(SUM(total), 0) AS ingresos "
                   + "FROM pedidos "
                   + "WHERE estado = 'ENTREGADO' "
                   + "AND fecha >= ? "
                   + "AND fecha < DATE_ADD(?, INTERVAL 1 DAY) "
                   + "GROUP BY DATE(fecha) "
                   + "ORDER BY dia";

        try (Connection conexion = Conexion.conectar();
             PreparedStatement sentencia = conexion.prepareStatement(sql)) {

            sentencia.setDate(1, desde);
            sentencia.setDate(2, hasta);

            try (ResultSet resultado = sentencia.executeQuery()) {
                while (resultado.next()) {
                    Object[] fila = {
                        resultado.getDate("dia"),
                        resultado.getInt("cantidad_pedidos"),
                        resultado.getDouble("ingresos")
                    };

                    lista.add(fila);
                }
            }

        } catch (Exception e) {
            System.out.println("Error al consultar pedidos por periodo: "
                    + e.getMessage());
        }

        return lista;
    }

    // 4. VENTAS DE LIVES POR PERIODO
    public ArrayList<Object[]> ventasLivePorPeriodo(
            Date desde, Date hasta) {

        ArrayList<Object[]> lista = new ArrayList<>();

        String sql = "SELECT DATE(v.fecha_hora) AS dia, "
                   + "COUNT(*) AS cantidad_ventas, "
                   + "COALESCE(SUM(v.total), 0) AS ingresos "
                   + "FROM ventas v "
                   + "WHERE v.canal = 'LIVE' "
                   + "AND v.fecha_hora >= ? "
                   + "AND v.fecha_hora < DATE_ADD(?, INTERVAL 1 DAY) "
                   + "GROUP BY DATE(v.fecha_hora) "
                   + "ORDER BY dia";

        try (Connection conexion = Conexion.conectar();
             PreparedStatement sentencia = conexion.prepareStatement(sql)) {

            sentencia.setDate(1, desde);
            sentencia.setDate(2, hasta);

            try (ResultSet resultado = sentencia.executeQuery()) {
                while (resultado.next()) {
                    Object[] fila = {
                        resultado.getDate("dia"),
                        resultado.getInt("cantidad_ventas"),
                        resultado.getDouble("ingresos")
                    };

                    lista.add(fila);
                }
            }

        } catch (Exception e) {
            System.out.println("Error al consultar ventas Live: "
                    + e.getMessage());
        }

        return lista;
    }

    // 5. PRODUCTOS MAS VENDIDOS EN LIVE Y TIENDA
    public ArrayList<Object[]> productosMasVendidos(
            Date desde, Date hasta) {

        ArrayList<Object[]> lista = new ArrayList<>();

        String sql = "SELECT p.id_producto, p.nombre, "
                   + "SUM(datos.cantidad) AS unidades_vendidas, "
                   + "SUM(datos.subtotal) AS importe_total "
                   + "FROM productos p "
                   + "INNER JOIN ( "

                   + "SELECT dv.id_producto, dv.cantidad, dv.subtotal "
                   + "FROM ventas v "
                   + "INNER JOIN detalle_ventas dv "
                   + "ON v.id_venta = dv.id_venta "
                   + "WHERE v.canal = 'LIVE' "
                   + "AND v.fecha_hora >= ? "
                   + "AND v.fecha_hora < DATE_ADD(?, INTERVAL 1 DAY) "

                   + "UNION ALL "

                   + "SELECT dp.id_producto, dp.cantidad, dp.subtotal "
                   + "FROM pedidos pe "
                   + "INNER JOIN detalle_pedidos dp "
                   + "ON pe.id_pedido = dp.id_pedido "
                   + "WHERE pe.estado = 'ENTREGADO' "
                   + "AND pe.fecha >= ? "
                   + "AND pe.fecha < DATE_ADD(?, INTERVAL 1 DAY) "

                   + ") AS datos "
                   + "ON p.id_producto = datos.id_producto "
                   + "GROUP BY p.id_producto, p.nombre "
                   + "ORDER BY unidades_vendidas DESC "
                   + "LIMIT 10";

        try (Connection conexion = Conexion.conectar();
             PreparedStatement sentencia = conexion.prepareStatement(sql)) {

            sentencia.setDate(1, desde);
            sentencia.setDate(2, hasta);
            sentencia.setDate(3, desde);
            sentencia.setDate(4, hasta);

            try (ResultSet resultado = sentencia.executeQuery()) {
                while (resultado.next()) {
                    Object[] fila = {
                        resultado.getInt("id_producto"),
                        resultado.getString("nombre"),
                        resultado.getInt("unidades_vendidas"),
                        resultado.getDouble("importe_total")
                    };

                    lista.add(fila);
                }
            }

        } catch (Exception e) {
            System.out.println("Error al consultar productos vendidos: "
                    + e.getMessage());
        }

        return lista;
    }

    // 6. RESUMEN GENERAL DE INGRESOS DE LIVE Y TIENDA
    public ArrayList<Object[]> resumenIngresosIntegrados(
            Date desde, Date hasta) {

        ArrayList<Object[]> lista = new ArrayList<>();

        String sql = "SELECT "

                   + "(SELECT COUNT(*) "
                   + "FROM ventas v "
                   + "WHERE v.canal = 'LIVE' "
                   + "AND v.fecha_hora >= ? "
                   + "AND v.fecha_hora < DATE_ADD(?, INTERVAL 1 DAY) "
                   + ") AS cantidad_ventas_live, "

                   + "(SELECT COALESCE(SUM(v.total), 0) "
                   + "FROM ventas v "
                   + "WHERE v.canal = 'LIVE' "
                   + "AND v.fecha_hora >= ? "
                   + "AND v.fecha_hora < DATE_ADD(?, INTERVAL 1 DAY) "
                   + ") AS ingresos_live, "

                   + "(SELECT COUNT(*) "
                   + "FROM pedidos p "
                   + "WHERE p.estado = 'ENTREGADO' "
                   + "AND p.fecha >= ? "
                   + "AND p.fecha < DATE_ADD(?, INTERVAL 1 DAY) "
                   + ") AS pedidos_entregados, "

                   + "(SELECT COALESCE(SUM(p.total), 0) "
                   + "FROM pedidos p "
                   + "WHERE p.estado = 'ENTREGADO' "
                   + "AND p.fecha >= ? "
                   + "AND p.fecha < DATE_ADD(?, INTERVAL 1 DAY) "
                   + ") AS ingresos_tienda";

        try (Connection conexion = Conexion.conectar();
             PreparedStatement sentencia = conexion.prepareStatement(sql)) {

            sentencia.setDate(1, desde);
            sentencia.setDate(2, hasta);

            sentencia.setDate(3, desde);
            sentencia.setDate(4, hasta);

            sentencia.setDate(5, desde);
            sentencia.setDate(6, hasta);

            sentencia.setDate(7, desde);
            sentencia.setDate(8, hasta);

            try (ResultSet resultado = sentencia.executeQuery()) {
                if (resultado.next()) {

                    double ingresosLive =
                            resultado.getDouble("ingresos_live");

                    double ingresosTienda =
                            resultado.getDouble("ingresos_tienda");

                    Object[] fila = {
                        resultado.getInt("cantidad_ventas_live"),
                        ingresosLive,
                        resultado.getInt("pedidos_entregados"),
                        ingresosTienda,
                        ingresosLive + ingresosTienda
                    };

                    lista.add(fila);
                }
            }

        } catch (Exception e) {
            System.out.println("Error al generar resumen integrado: "
                    + e.getMessage());
        }

        return lista;
    }
}
